#!/bin/bash
echo ""
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║          🚀 Starting FlexBoard OnPrem...                  ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

# GitHub Container Registry credentials
GHCR_TOKEN="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"
GHCR_USER="watthachai"

# Default SQL Port
SQL_PORT=1433
USE_DEMO_DB=true

# Check if port 1433 is already in use (skip if our demo-db is already using it)
check_port() {
    if lsof -i :$1 > /dev/null 2>&1 || netstat -an 2>/dev/null | grep -q ":$1 "; then
        # Check if it's our demo-db container
        if docker ps --format '{{.Names}}' 2>/dev/null | grep -q "flexboard-demo-db"; then
            return 1  # Our container, OK
        fi
        return 0  # Port in use by something else
    fi
    return 1  # Port is free
}

# Check if demo-db is in docker-compose.yml
if grep -q "demo-db:" docker-compose.yml 2>/dev/null; then
    echo "🔍 Checking port availability..."
    
    if check_port 1433; then
        echo ""
        echo "╔═══════════════════════════════════════════════════════════╗"
        echo "║  ⚠️  WARNING: Port 1433 is already in use!                ║"
        echo "╚═══════════════════════════════════════════════════════════╝"
        echo ""
        echo "   Another SQL Server or service is already using port 1433."
        echo ""
        echo "   Options:"
        echo "   1. Use your existing SQL Server (recommended)"
        echo "      → Update DataSource in Admin UI to point to your server"
        echo ""
        echo "   2. Change Demo DB port to 1434"
        echo "      → Edit docker-compose.yml: change '1433:1433' to '1434:1433'"
        echo "      → Update DataSource port in Admin UI to 1434"
        echo ""
        echo "   3. Stop the existing SQL Server service"
        echo "      → macOS: brew services stop mssql-server"
        echo "      → Linux: sudo systemctl stop mssql-server"
        echo "      → Windows: Stop SQL Server service"
        echo ""
        read -p "   Press Enter to continue without Demo DB, or Ctrl+C to cancel... "
        USE_DEMO_DB=false
        
        # Comment out demo-db from docker-compose
        echo ""
        echo "📝 Disabling Demo DB in docker-compose.yml..."
        sed -i.bak '/demo-db:/,/healthcheck:/{ s/^/#/; }' docker-compose.yml 2>/dev/null || \
        sed -i '' '/demo-db:/,/start_period:/{ s/^/# /; }' docker-compose.yml 2>/dev/null
    else
        echo "✅ Port 1433 is available"
    fi
fi
echo ""

# Login to GitHub Container Registry
echo "🔐 Logging in to GitHub Container Registry..."
echo "$GHCR_TOKEN" | docker login ghcr.io -u "$GHCR_USER" --password-stdin
if [ $? -ne 0 ]; then
    echo ""
    echo "❌ Failed to login to GitHub Container Registry"
    echo "   Please check your internet connection and try again."
    exit 1
fi
echo "✅ Logged in successfully!"
echo ""

# Clean up old containers if they exist
echo "🧹 Cleaning up old containers..."
docker rm -f flexboard-proxy-prod flexboard-proxy-staging flexboard-frontend-prod flexboard-frontend-staging flexboard-demo-db 2>/dev/null || true

echo ""
echo "📥 Pulling latest images..."
docker-compose pull

echo ""
echo "🔄 Starting services..."
docker-compose up -d

echo ""
echo "⏳ Waiting for services to start..."
sleep 5

# If demo-db exists and we're using it, run init script
if [ "$USE_DEMO_DB" = true ] && docker ps | grep -q "flexboard-demo-db"; then
    echo ""
    echo "╔═══════════════════════════════════════════════════════════╗"
    echo "║          🗄️  Initializing Demo Database...                ║"
    echo "╚═══════════════════════════════════════════════════════════╝"
    echo ""
    echo "⏳ This may take up to 2 minutes on first run..."
    echo ""
    
    # Copy init script with proper permissions
    docker cp ./demo-db/init-db.sh flexboard-demo-db:/tmp/init-db.sh 2>/dev/null
    docker exec -u root flexboard-demo-db chmod +x /tmp/init-db.sh 2>/dev/null
    
    # Run init script
    docker exec flexboard-demo-db /bin/bash /tmp/init-db.sh
    
    if [ $? -ne 0 ]; then
        echo ""
        echo "⚠️  Database initialization had issues. You can retry manually:"
        echo "   docker exec flexboard-demo-db /bin/bash /tmp/init-db.sh"
    fi
fi

# Check if services are running
echo ""
if docker-compose ps | grep -q "Up"; then
    echo "╔═══════════════════════════════════════════════════════════╗"
    echo "║                  ✅ FlexBoard is Running!                 ║"
    echo "╚═══════════════════════════════════════════════════════════╝"
    echo ""
    echo "📍 Open in browser:"
    echo "   • Production: http://localhost:3000"
    if docker-compose ps | grep -q "staging"; then
        echo "   • Staging:    http://localhost:3001"
    fi
    echo ""
    if [ "$USE_DEMO_DB" = true ] && docker ps | grep -q "flexboard-demo-db"; then
        echo "📊 Demo Database:"
        echo "   • Host:     localhost"
        echo "   • Port:     1433"
        echo "   • Database: shareddata"
        echo "   • User:     sa"
        echo "   • Password: Test@1234!"
        echo ""
    elif [ "$USE_DEMO_DB" = false ]; then
        echo "📊 Database:"
        echo "   • Demo DB was skipped (port 1433 in use)"
        echo "   • Please configure your DataSource in Admin UI"
        echo ""
    fi
    echo "💡 Commands:"
    echo "   • Stop:    ./stop.sh"
    echo "   • Logs:    docker-compose logs -f"
    echo "   • Upgrade: ./upgrade.sh"
    echo ""
else
    echo "❌ Failed to start. Check logs with: docker-compose logs"
fi
