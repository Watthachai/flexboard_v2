#!/bin/bash
echo "⬆️  Upgrading FlexBoard OnPrem..."
echo ""
echo "📥 Pulling latest images..."
docker-compose pull

echo ""
echo "🔄 Recreating containers with new images..."
docker-compose up -d --force-recreate

echo ""
echo "✅ Upgrade complete!"
echo ""
echo "📋 Current versions:"
docker-compose images
