#!/bin/bash
echo "🛑 Stopping FlexBoard OnPrem..."
docker-compose down
echo "✅ FlexBoard stopped"
