@echo off
setlocal enabledelayedexpansion

echo.
echo ============================================================
echo           Starting FlexBoard OnPrem...
echo ============================================================
echo.

REM Check if Docker is running
echo [INFO] Checking Docker...
docker info >nul 2>&1
if !errorlevel! neq 0 (
    echo.
    echo ============================================================
    echo   [ERROR] Docker is not running!
    echo ============================================================
    echo.
    echo   Please start Docker Desktop first:
    echo   1. Click Start Menu
    echo   2. Search for "Docker Desktop"
    echo   3. Open Docker Desktop and wait until it's running
    echo   4. Run this script again
    echo.
    pause
    exit /b 1
)
echo [OK] Docker is running
echo.

REM GitHub Container Registry credentials
set "GHCR_TOKEN=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"
set "GHCR_USER=watthachai"

echo [INFO] Logging in to GitHub Container Registry...
echo !GHCR_TOKEN!| docker login ghcr.io -u !GHCR_USER! --password-stdin
if !errorlevel! neq 0 (
    echo.
    echo [ERROR] Failed to login to GitHub Container Registry
    echo         Please check your internet connection and try again.
    pause
    exit /b 1
)
echo [OK] Logged in successfully!
echo.

echo [INFO] Cleaning up old containers...
docker rm -f flexboard-proxy-prod flexboard-proxy-staging flexboard-frontend-prod flexboard-frontend-staging flexboard-demo-db 2>nul

echo.
echo [INFO] Pulling latest images...
docker-compose pull
if !errorlevel! neq 0 (
    echo [ERROR] Failed to pull images. Please check your internet connection.
    pause
    exit /b 1
)

echo.
echo [INFO] Starting services...
docker-compose up -d

echo.
echo [INFO] Waiting for services to start...
timeout /t 15 /nobreak > nul

REM Initialize demo database if exists
docker ps | findstr "flexboard-demo-db" > nul
if !errorlevel! equ 0 (
    echo.
    echo ============================================================
    echo           Initializing Demo Database...
    echo ============================================================
    echo.
    echo [INFO] This may take up to 2 minutes on first run...
    
    docker cp demo-db\init-db.sh flexboard-demo-db:/tmp/init-db.sh 2>nul
    docker exec -u root flexboard-demo-db chmod +x /tmp/init-db.sh 2>nul
    docker exec flexboard-demo-db /bin/bash /tmp/init-db.sh
)

echo.
echo ============================================================
echo              FlexBoard is Running!
echo ============================================================
echo.
echo Open in browser:
echo    - Production: http://localhost:3000
echo    - Staging:    http://localhost:3001
echo.
echo Demo Database:
echo    - Host:     localhost
echo    - Port:     1433
echo    - Database: shareddata
echo    - User:     sa
echo    - Password: Test@1234!
echo.
echo Commands:
echo    - Stop:    stop.bat
echo    - Logs:    docker-compose logs -f
echo    - Upgrade: upgrade.bat
echo.
pause
endlocal
