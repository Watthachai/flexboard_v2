@echo off
echo [INFO] Stopping FlexBoard OnPrem...
docker-compose down
echo [OK] FlexBoard stopped
pause
