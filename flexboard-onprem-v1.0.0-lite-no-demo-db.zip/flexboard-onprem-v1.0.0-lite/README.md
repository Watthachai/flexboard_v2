# FlexBoard Dashboard - คู่มือติดตั้ง (Lite)

Version: v1.0.0  
Registry: ghcr.io/watthachai

## ความต้องการของระบบ

- **Docker Desktop** (Windows/Mac) หรือ **Docker Engine** (Linux)
- **Internet connection** สำหรับ pull images และ authentication
- **API Key** (ติดต่อ Admin)

## การติดตั้ง

### Windows

1. ติดตั้ง [Docker Desktop](https://www.docker.com/products/docker-desktop/)
2. เปิด Docker Desktop และรอให้ running
3. ดับเบิลคลิก `start.bat`
4. รอจนติดตั้งเสร็จ (จะ pull images อัตโนมัติ)

### macOS / Linux

```bash
chmod +x *.sh
./start.sh
```

## การใช้งาน

| Command | Windows | Mac/Linux |
|---------|---------|-----------|
| เริ่มต้น | `start.bat` | `./start.sh` |
| หยุด | `stop.bat` | `./stop.sh` |
| อัพเกรด | `upgrade.bat` | `./upgrade.sh` |

## การเข้าใช้งาน

| Environment | URL | API Key |
|-------------|-----|---------|
| Production | http://localhost:3000 | (ติดต่อ Admin) |
| Staging | http://localhost:3001 | (ติดต่อ Admin) |

## การอัพเกรด Version ใหม่

เมื่อมี version ใหม่ เพียงแค่รัน:

```bash
./upgrade.sh
```

หรือบน Windows: ดับเบิลคลิก `upgrade.bat`

ระบบจะ pull images ใหม่และ restart อัตโนมัติ

## Ports ที่ใช้งาน

| Service | Port |
|---------|------|
| Production Dashboard | 3000 |
| Production Proxy | 5001 |
| Staging Dashboard | 3001 |
| Staging Proxy | 5002 |

## Support

📧 Email: support@fittflexb.com
