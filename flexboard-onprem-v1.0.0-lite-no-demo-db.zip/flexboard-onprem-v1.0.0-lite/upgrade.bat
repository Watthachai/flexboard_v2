@echo off
echo [INFO] Upgrading FlexBoard OnPrem...
echo.
echo [INFO] Pulling latest images...
docker-compose pull

echo.
echo [INFO] Recreating containers with new images...
docker-compose up -d --force-recreate

echo.
echo [OK] Upgrade complete!
pause
