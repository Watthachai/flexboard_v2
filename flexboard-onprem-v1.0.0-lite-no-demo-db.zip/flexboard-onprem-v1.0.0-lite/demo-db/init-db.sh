#!/bin/bash
SA_PASSWORD="Test@1234!"
MAX_RETRIES=60
RETRY_INTERVAL=2

echo "=============================================="
echo "  FlexBoard Demo Database Initialization"
echo "=============================================="
echo ""
echo "⏳ Waiting for SQL Server to start..."

# Wait for SQL Server to be ready (up to 2 minutes)
for i in $(seq 1 $MAX_RETRIES); do
    /opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P "$SA_PASSWORD" -C -Q "SELECT 1" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "✅ SQL Server is ready! (after ${i} attempts)"
        break
    fi
    if [ $i -eq $MAX_RETRIES ]; then
        echo "❌ SQL Server failed to start after $MAX_RETRIES attempts"
        exit 1
    fi
    echo "   Waiting for SQL Server... ($i/$MAX_RETRIES)"
    sleep $RETRY_INTERVAL
done

# Check if database already exists and has data
echo ""
echo "🔍 Checking existing database..."
DB_EXISTS=$(/opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P "$SA_PASSWORD" -C -Q "SELECT COUNT(*) FROM sys.databases WHERE name = 'shareddata'" -h -1 2>/dev/null | tr -d ' ')

if [ "$DB_EXISTS" = "1" ]; then
    # Check if table exists
    TABLE_EXISTS=$(/opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P "$SA_PASSWORD" -C -d shareddata -Q "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'VVPVSG_INVENTORY_001_VIEW_001'" -h -1 2>/dev/null | tr -d ' ')
    if [ "$TABLE_EXISTS" = "1" ]; then
        echo "✅ Database 'shareddata' already exists with data. Skipping initialization."
        echo ""
        echo "📌 Connection Info:"
        echo "   Host:     localhost (or host.docker.internal from Docker)"
        echo "   Port:     1433"
        echo "   Database: shareddata"
        echo "   User:     sa"
        echo "   Password: $SA_PASSWORD"
        exit 0
    fi
fi

# Create database if not exists
echo ""
echo "📦 Creating database 'shareddata'..."
/opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P "$SA_PASSWORD" -C -Q "
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'shareddata')
BEGIN
    CREATE DATABASE shareddata;
    PRINT 'Database shareddata created!';
END
ELSE
BEGIN
    PRINT 'Database shareddata already exists.';
END
"

# Wait a moment for database to be ready
sleep 2

# Import sample data
echo ""
echo "📊 Importing sample data..."
/opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P "$SA_PASSWORD" -C -d shareddata -i /docker-entrypoint-initdb.d/sample_data.sql

if [ $? -eq 0 ]; then
    echo ""
    echo "=============================================="
    echo "  ✅ Demo Database Setup Complete!"
    echo "=============================================="
    echo ""
    echo "📌 Connection Info:"
    echo "   Host:     localhost (or host.docker.internal from Docker)"
    echo "   Port:     1433"
    echo "   Database: shareddata"
    echo "   User:     sa"
    echo "   Password: $SA_PASSWORD"
else
    echo ""
    echo "❌ Failed to import sample data"
    exit 1
fi
