/* ===========================================
   1) Create table if not exists
   =========================================== */
IF OBJECT_ID(N'[dbo].[VVPVSG_INVENTORY_001_VIEW_001]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[VVPVSG_INVENTORY_001_VIEW_001] (
        dataDate              DATETIME2       NOT NULL,
        corp                  NVARCHAR(255)   NOT NULL,
        branch                NVARCHAR(255)   NOT NULL,
        prodCode              NVARCHAR(200)   NOT NULL,
        prodName              NVARCHAR(400)   NOT NULL,
        unitName              NVARCHAR(100)   NOT NULL,
        prodGrp               NVARCHAR(200)       NULL,
        docNumber             NVARCHAR(200)   NOT NULL,
        docDate               DATETIME2       NOT NULL,
        qtyFromThisDoc        FLOAT           NOT NULL,
        buyPrice              FLOAT               NULL,
        averageCost           FLOAT           NOT NULL,
        totalFromBuyPrice     FLOAT               NULL,
        totalFromAverageCost  FLOAT               NULL,
        daysAge               INT                 NULL,
        ageBucket             NVARCHAR(100)       NULL,
        createDate            DATETIME2       NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT PK_VVPVSG PRIMARY KEY (dataDate, corp, branch, prodCode, docNumber)
    );
END
GO

/* Optional local-only: Uncomment if you want to reset data on re-run
-- TRUNCATE TABLE [dbo].[VVPVSG_INVENTORY_001_VIEW_001];
*/

/* ===========================================
   2) INSERT Data
   =========================================== */

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0688',
 '2025-06-28',
 93, 29.85, -121996.19, 2776.05, -11345645.6699999999,
 2, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0685',
 '2025-06-27',
 45, 29.85, -121996.19, 1343.25, -5489828.5499999998,
 3, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0671',
 '2025-06-26',
 30, 29.85, -121996.19, 895.5, -3659885.7000000002,
 4, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0663',
 '2025-06-25',
 92, 29.85, -121996.19, 2746.2, -11223649.4800000004,
 5, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0650',
 '2025-06-24',
 148, 29.85, -121996.19, 4417.8, -18055436.120000001,
 6, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0640',
 '2025-06-21',
 150, 29.85, -121996.19, 4477.5, -18299428.5,
 9, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0635',
 '2025-06-20',
 45, 29.85, -121996.19, 1343.25, -5489828.5499999998,
 10, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0631',
 '2025-06-19',
 116, 29.85, -121996.19, 3462.6, -14151558.0399999991,
 11, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0626',
 '2025-06-17',
 72, 29.85, -121996.19, 2149.2, -8783725.6799999997,
 13, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0622',
 '2025-06-16',
 40, 29.85, -121996.19, 1194, -4879847.5999999996,
 14, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'9506140291',
 '2025-06-14',
 77, 30.0667, -121996.19, 2315.1359, -9393706.6300000008,
 16, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0615',
 '2025-06-13',
 159, 29.85, -121996.19, 4746.15, -19397394.2100000009,
 17, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'4506110225',
 '2025-06-11',
 189.38, 30.1031, -121996.19, 5700.925078, -23103638.4622000009,
 19, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0609',
 '2025-06-11',
 60, 29.85, -121996.19, 1791, -7319771.4000000004,
 19, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0605',
 '2025-06-10',
 99, 29.85, -121996.19, 2955.15, -12077622.8100000005,
 20, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'000104',
 '2025-06-09',
 129.92, 30.3926, -121996.19, 3948.606592, -15849745.0047999993,
 21, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0600',
 '2025-06-09',
 112, 29.85, -121996.19, 3343.2, -13663573.2799999993,
 21, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0590',
 '2025-06-06',
 65, 29.85, -121996.19, 1940.25, -7929752.3499999996,
 24, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0588',
 '2025-06-05',
 109, 29.85, -121996.19, 3253.65, -13297584.7100000009,
 25, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0583',
 '2025-06-04',
 39, 29.85, -121996.19, 1164.15, -4757851.4100000001,
 26, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0578',
 '2025-06-02',
 85, 29.85, -121996.19, 2537.25, -10369676.1500000004,
 28, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0574',
 '2025-05-31',
 30, 29.85, -121996.19, 895.5, -3659885.7000000002,
 30, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0571',
 '2025-05-30',
 70, 29.85, -121996.19, 2089.5, -8539733.3000000007,
 31, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0567',
 '2025-05-29',
 155, 29.85, -121996.19, 4626.75, -18909409.4499999993,
 32, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0564',
 '2025-05-28',
 102, 29.85, -121996.19, 3044.7, -12443611.3800000008,
 33, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'8505270184',
 '2025-05-27',
 121.56, 30.2149, -121996.19, 3672.923244, -14829856.8563999999,
 34, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0550',
 '2025-05-27',
 174, 29.85, -121996.19, 5193.9, -21227337.0599999987,
 34, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0542',
 '2025-05-26',
 126, 29.85, -121996.19, 3761.1, -15371519.9399999995,
 35, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'4505240541',
 '2025-05-24',
 125.43, 30.1022, -121996.19, 3775.718946, -15301982.1117000002,
 37, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0528',
 '2025-05-24',
 213, 29.85, -121996.19, 6358.05, -25985188.4699999988,
 37, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'0000086',
 '2025-05-22',
 147.91, 30.3923, -121996.19, 4495.325093, -18044456.4629000016,
 39, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0516',
 '2025-05-22',
 76, 29.85, -121996.19, 2268.6, -9271710.4399999995,
 39, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0513',
 '2025-05-21',
 284, 29.85, -121996.19, 8477.4, -34646917.9600000009,
 40, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'DSW-001-05-68',
 '2025-05-20',
 400, 30.1601, -121996.19, 12064.04, -48798476,
 41, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'IB.68/0507',
 '2025-05-19',
 236, 29.85, -121996.19, 7044.6, -28791100.8399999999,
 42, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU009',
 N'น้ำมันดีเซล-เติมรถ',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'4505170375',
 '2025-05-17',
 55.86, 30.102, -121996.19, 1681.49772, -6814707.1733999997,
 44, N'0-90 Days', '2025-09-29T16:01:12.400');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU006',
 N'Sodium Blend',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'SPA-014-6-68',
 '2025-06-28',
 1000, 1.4305, 165.72, 1430.5, 165720,
 2, N'0-90 Days', '2025-09-29T16:01:12.107');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU006',
 N'Sodium Blend',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'SPA-013-6-68',
 '2025-06-27',
 1000, 1.4305, 165.72, 1430.5, 165720,
 3, N'0-90 Days', '2025-09-29T16:01:12.107');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU006',
 N'Sodium Blend',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'SP-004-6-68',
 '2025-06-25',
 803, 1.4305, 165.72, 1148.6915, 133073.16,
 5, N'0-90 Days', '2025-09-29T16:01:12.107');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU006',
 N'Sodium Blend',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'SPA-012-6-68',
 '2025-06-25',
 1000, 1.4305, 165.72, 1430.5, 165720,
 5, N'0-90 Days', '2025-09-29T16:01:12.107');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU005',
 N'Citric Blend',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'SPA-014-6-68',
 '2025-06-28',
 857, 3.7701, 427.09, 3230.9757, 366016.13,
 2, N'0-90 Days', '2025-09-29T16:01:11.900');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU005',
 N'Citric Blend',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'SPA-013-6-68',
 '2025-06-27',
 857, 3.7701, 427.09, 3230.9757, 366016.13,
 3, N'0-90 Days', '2025-09-29T16:01:11.900');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU005',
 N'Citric Blend',
 N'ลิตร',
 N'1-000003-Raw Materials',
 N'SPA-012-6-68',
 '2025-06-25',
 821, 3.7701, 427.09, 3095.2521, 350640.89,
 5, N'0-90 Days', '2025-09-29T16:01:11.900');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU004',
 N'Sodium Nitrite',
 N'KG',
 N'1-000003.1-Raw Materials (Mixing Oxidizing Agent)',
 N'TSA/SN/2568/003',
 '2025-06-25',
 1000, 28.6091, 212.05, 28609.1, 212050,
 5, N'0-90 Days', '2025-09-29T16:01:11.877');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU004',
 N'Sodium Nitrite',
 N'KG',
 N'1-000003.1-Raw Materials (Mixing Oxidizing Agent)',
 N'ARL2506200124',
 '2025-06-20',
 8000, 28, 212.05, 224000, 1696400,
 10, N'0-90 Days', '2025-09-29T16:01:11.877');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU004',
 N'Sodium Nitrite',
 N'KG',
 N'1-000003.1-Raw Materials (Mixing Oxidizing Agent)',
 N'ARL2505190025',
 '2025-05-19',
 1000, 30, 212.05, 30000, 212050,
 42, N'0-90 Days', '2025-09-29T16:01:11.877');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU004',
 N'Sodium Nitrite',
 N'KG',
 N'1-000003.1-Raw Materials (Mixing Oxidizing Agent)',
 N'TSA/SN/2568/002',
 '2025-05-07',
 1000, 29.3153, 212.05, 29315.3, 212050,
 54, N'0-90 Days', '2025-09-29T16:01:11.877');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU004',
 N'Sodium Nitrite',
 N'KG',
 N'1-000003.1-Raw Materials (Mixing Oxidizing Agent)',
 N'ARL2504190107',
 '2025-04-19',
 1750, 30, 212.05, 52500, 371087.5,
 72, N'0-90 Days', '2025-09-29T16:01:11.877');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU003',
 N'Citric Acid Anhydrous',
 N'KG',
 N'1-000003.1-Raw Materials (Mixing Oxidizing Agent)',
 N'AJ0011/5401319',
 '2025-06-25',
 2000, 43.0797, 413.26, 86159.4, 826520,
 5, N'0-90 Days', '2025-09-29T16:01:11.857');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU003',
 N'Citric Acid Anhydrous',
 N'KG',
 N'1-000003.1-Raw Materials (Mixing Oxidizing Agent)',
 N'TSA/CA/2568/004',
 '2025-06-24',
 1000, 43.0797, 413.26, 43079.7, 413260,
 6, N'0-90 Days', '2025-09-29T16:01:11.857');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU003',
 N'Citric Acid Anhydrous',
 N'KG',
 N'1-000003.1-Raw Materials (Mixing Oxidizing Agent)',
 N'INF68060802',
 '2025-06-21',
 6000, 41, 413.26, 246000, 2479560,
 9, N'0-90 Days', '2025-09-29T16:01:11.857');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU003',
 N'Citric Acid Anhydrous',
 N'KG',
 N'1-000003.1-Raw Materials (Mixing Oxidizing Agent)',
 N'IVF2510556',
 '2025-06-01',
 1000, 45, 413.26, 45000, 413260,
 29, N'0-90 Days', '2025-09-29T16:01:11.857');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU003',
 N'Citric Acid Anhydrous',
 N'KG',
 N'1-000003.1-Raw Materials (Mixing Oxidizing Agent)',
 N'TSA/CA/2568/003',
 '2025-05-08',
 575, 44.7594, 413.26, 25736.655, 237624.5,
 53, N'0-90 Days', '2025-09-29T16:01:11.857');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU002A-Local',
 N'Ammonium Nitrate - PP (32)',
 N'KG',
 N'1-000003-Raw Materials',
 N'INV25-1684',
 '2025-06-27',
 30000, 15.28, 16.06, 458400, 481800,
 3, N'0-90 Days', '2025-09-29T16:01:11.843');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU002A-Local',
 N'Ammonium Nitrate - PP (32)',
 N'KG',
 N'1-000003-Raw Materials',
 N'INV25-1614',
 '2025-06-20',
 7480, 15.28, 16.06, 114294.4, 120128.8,
 10, N'0-90 Days', '2025-09-29T16:01:11.843');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU002- Local',
 N'Ammonium Nitrate - PP (672)',
 N'KG',
 N'1-000003-Raw Materials',
 N'INV25-1691',
 '2025-06-30',
 50000, 15.78, 354.77, 789000, 17738500,
 0, N'0-90 Days', '2025-09-29T16:01:11.817');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU002- Local',
 N'Ammonium Nitrate - PP (672)',
 N'KG',
 N'1-000003-Raw Materials',
 N'INV25-1564',
 '2025-06-17',
 45980, 15.78, 354.77, 725564.4, 16312324.5999999996,
 13, N'0-90 Days', '2025-09-29T16:01:11.817');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU001-Matrix',
 N'Bulk Emulsion (Matrix)',
 N'KG',
 N'1-000002-Emulsion : Bulk (Blend)',
 N'IV.68/0643',
 '2025-06-29',
 4900, 16.01, 16.48, 78449, 80752,
 1, N'0-90 Days', '2025-09-29T16:01:11.807');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU001-Matrix',
 N'Bulk Emulsion (Matrix)',
 N'KG',
 N'1-000002-Emulsion : Bulk (Blend)',
 N'IV.68/0642',
 '2025-06-28',
 23830, 16.01, 16.48, 381518.3, 392718.4,
 2, N'0-90 Days', '2025-09-29T16:01:11.807');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU001- Hydrox S',
 N'Bulk Emulsion (Hydrox S)',
 N'KG',
 N'1-000002-Emulsion : Bulk (Blend)',
 N'IV.68/0639',
 '2025-06-27',
 28370, 16.68, 27.16, 473211.6, 770529.2,
 3, N'0-90 Days', '2025-09-29T16:01:11.723');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU001- Hydrox S',
 N'Bulk Emulsion (Hydrox S)',
 N'KG',
 N'1-000002-Emulsion : Bulk (Blend)',
 N'IV.68/0626',
 '2025-06-24',
 5000, 16.68, 27.16, 83400, 135800,
 6, N'0-90 Days', '2025-09-29T16:01:11.723');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU001- Hydrox S',
 N'Bulk Emulsion (Hydrox S)',
 N'KG',
 N'1-000002-Emulsion : Bulk (Blend)',
 N'IV.68/0613',
 '2025-06-20',
 17000, 16.68, 27.16, 283560, 461720,
 10, N'0-90 Days', '2025-09-29T16:01:11.723');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU001- Hydrox S',
 N'Bulk Emulsion (Hydrox S)',
 N'KG',
 N'1-000002-Emulsion : Bulk (Blend)',
 N'IV.68/0602',
 '2025-06-18',
 10830, 16.68, 27.16, 180644.4, 294142.8,
 12, N'0-90 Days', '2025-09-29T16:01:11.723');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU001- Export Hydrox S',
 N'Bulk Emulsion (Matrix)',
 N'KG',
 N'1-000001-Emulsion : Bulk (Export)',
 N'IV.68/0629',
 '2025-06-25',
 16000, 16.68, 7228.46, 266880, 115655360,
 5, N'0-90 Days', '2025-09-29T16:01:11.600');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU001- Export',
 N'Bulk Emulsion (Matrix)',
 N'KG',
 N'1-000001-Emulsion : Bulk (Export)',
 N'IV.68/0636',
 '2025-06-27',
 52000, 16.01, 4250.6, 832520, 221031200,
 3, N'0-90 Days', '2025-09-29T16:01:10.780');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU001- Export',
 N'Bulk Emulsion (Matrix)',
 N'KG',
 N'1-000001-Emulsion : Bulk (Export)',
 N'IV.68/0637',
 '2025-06-27',
 84000, 16.01, 4250.6, 1344840, 357050400,
 3, N'0-90 Days', '2025-09-29T16:01:10.780');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TKPV-TKPV CO., LTD.',
 N'00001-สำนักงานใหญ่',
 N'BU001- Export',
 N'Bulk Emulsion (Matrix)',
 N'KG',
 N'1-000001-Emulsion : Bulk (Export)',
 N'IV.68/0634',
 '2025-06-26',
 18000, 16.01, 4250.6, 288180, 76510800,
 4, N'0-90 Days', '2025-09-29T16:01:10.780');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TERM_1-บริษัท เติมเอนยิเนียริ่ง จำกัด',
 N'00001-แก่งคอย',
 N'สายไฟ THW 1x25',
 N'สายไฟ THW 1x25',
 N'เมตร',
 N'0015-สายไฟ',
 N'HS5910546',
 '2016-10-26',
 300, 51.6, 51.6, 15480, 15480,
 3169, N'Over 365 Days', '2025-09-29T16:01:10.733');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TERM_1-บริษัท เติมเอนยิเนียริ่ง จำกัด',
 N'00001-แก่งคอย',
 N'AM004',
 N'DUMMY ดินอีมัลชั่น ขนาดใหญ่',
 N'นัด',
 N'0001-Emulsion',
 N'515/PFI',
 '2015-08-22',
 10, 0, 0, 0, 0,
 3600, N'Over 365 Days', '2025-09-29T16:01:10.723');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TERM_1-บริษัท เติมเอนยิเนียริ่ง จำกัด',
 N'00001-แก่งคอย',
 N'AM003',
 N'DUMMY ดินอีมัลชั่น ขนาดเล็ก',
 N'นัด',
 N'0001-Emulsion',
 N'515/PFI',
 '2015-08-22',
 10, 0, 0, 0, 0,
 3600, N'Over 365 Days', '2025-09-29T16:01:10.713');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TERM_1-บริษัท เติมเอนยิเนียริ่ง จำกัด',
 N'00001-แก่งคอย',
 N'AM002',
 N'DUMMY SURFACE DETONATORS 67MS 6 M',
 N'นัด',
 N'0005-EZ  DET',
 N'515/PFI',
 '2015-08-22',
 10, 0, 0, 0, 0,
 3600, N'Over 365 Days', '2025-09-29T16:01:10.700');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TERM_1-บริษัท เติมเอนยิเนียริ่ง จำกัด',
 N'00001-แก่งคอย',
 N'AM001',
 N'DUMMY DOUBLE DETONATORS 25/500 MS 18 M',
 N'นัด',
 N'0005-EZ  DET',
 N'515/PFI',
 '2015-08-22',
 10, 0, 0, 0, 0,
 3600, N'Over 365 Days', '2025-09-29T16:01:10.690');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TERM_1-บริษัท เติมเอนยิเนียริ่ง จำกัด',
 N'00001-แก่งคอย',
 N'AE-001',
 N'วัตถุระเบิด (อีมัลชั่น) 150 - 25 MM x 200 MM',
 N'นัด',
 N'0001-Emulsion',
 N'65112512',
 '2022-11-21',
 0.0002, 10.58, 4098910223.2100000381, 0.002116, 819782.044642,
 952, N'Over 365 Days', '2025-09-29T16:01:10.683');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TANJAI-บริษัท ทันใจ โลจิสติกส์ จำกัด',
 N'00000-สำนักงานใหญ่',
 N'455',
 N'เปลี่ยนน้ำมันเพาเวอร์+กรอง',
 N'คัน',
 N'001-ค่าบริการ',
 N'1CH-20090061',
 '2020-09-23',
 1, 642, 642, 642, 642,
 1741, N'Over 365 Days', '2025-09-29T16:01:10.677');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'TANJAI-บริษัท ทันใจ โลจิสติกส์ จำกัด',
 N'00000-สำนักงานใหญ่',
 N'455',
 N'เปลี่ยนน้ำมันเพาเวอร์+กรอง',
 N'คัน',
 N'001-ค่าบริการ',
 N'1CH-20080059',
 '2020-08-25',
 1, 642, 642, 642, 642,
 1770, N'Over 365 Days', '2025-09-29T16:01:10.677');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'SUPPLIES-บริษัท พี.วี.ซัพพลายส์ (ไทยแลนด์) จำกัด',
 N'00001-สำนักงานใหญ่',
 N'PRM(C)-05LC',
 N'Glass Micro Balloon Local',
 N'KG',
 N'--ไม่ระบุ',
 N'91453710',
 '2025-06-22',
 8880, 165.3086, 168.77, 1467940.368, 1498677.6000000001,
 8, N'0-90 Days', '2025-09-29T16:01:10.667');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'SUPPLIES-บริษัท พี.วี.ซัพพลายส์ (ไทยแลนด์) จำกัด',
 N'00001-สำนักงานใหญ่',
 N'PRM(C)-04LC',
 N'Solar Emulsifier Blend Local',
 N'KG',
 N'--ไม่ระบุ',
 N'0016871065',
 '2025-06-16',
 20000, 104.416, 109.07, 2088320, 2181400,
 14, N'0-90 Days', '2025-09-29T16:01:10.660');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'SUPPLIES-บริษัท พี.วี.ซัพพลายส์ (ไทยแลนด์) จำกัด',
 N'00001-สำนักงานใหญ่',
 N'PEO00009',
 N'FLUSHING COMPOUND',
 N'KG',
 N'--ไม่ระบุ',
 N'0016871065',
 '2025-06-16',
 2, 407.875, 413.13, 815.75, 826.26,
 14, N'0-90 Days', '2025-09-29T16:01:10.653');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'SUPPLIES-บริษัท พี.วี.ซัพพลายส์ (ไทยแลนด์) จำกัด',
 N'00001-สำนักงานใหญ่',
 N'ANCP - JB',
 N'Ammonium Nitrate Crystalline (JB)',
 N'KG',
 N'ANCP-Ammonium Nitrate Crystalline',
 N'0003',
 '2025-05-13',
 500000, 14.8118, 19.19, 7405900, 9595000,
 48, N'0-90 Days', '2025-09-29T16:01:10.647');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM01',
 N'น้ำมันเตาเกรด A',
 N'ลิตร',
 N'--ไม่ระบุ',
 N'68-01-00840-PMO',
 '2025-04-30',
 11000, 18.6, 18.6, 204600, 204600,
 61, N'0-90 Days', '2025-09-29T16:01:10.637');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-10LC',
 N'Paraffin wax Local',
 N'KG',
 N'--ไม่ระบุ',
 N'TINV-250633',
 '2025-06-27',
 10000, 67.5, 71.92, 675000, 719200,
 3, N'0-90 Days', '2025-09-29T16:01:10.623');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-10LC',
 N'Paraffin wax Local',
 N'KG',
 N'--ไม่ระบุ',
 N'HS6810303',
 '2025-04-29',
 1575, 100, 71.92, 157500, 113274,
 62, N'0-90 Days', '2025-09-29T16:01:10.623');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-09LC',
 N'Rhodamine Red Dye Local',
 N'KG',
 N'วัตถุดิบ-วัตถุดิบ',
 N'SP68/008',
 '2025-04-01',
 25, 709.74, 1008.03, 17743.5, 25200.75,
 90, N'0-90 Days', '2025-09-29T16:01:10.613');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-09LC',
 N'Rhodamine Red Dye Local',
 N'KG',
 N'วัตถุดิบ-วัตถุดิบ',
 N'PVI67/0420',
 '2024-12-30',
 3.22, 3323.98, 1008.03, 10703.2156, 3245.8566,
 182, N'181-365 Days', '2025-09-29T16:01:10.613');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-08',
 N'Sodium Nitrite (NaNO2)',
 N'KG',
 N'--ไม่ระบุ',
 N'IV6803-0085',
 '2025-03-19',
 325, 33, 33, 10725, 10725,
 103, N'91-180 Days', '2025-09-29T16:01:10.607');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-07LC',
 N'ANPP SB (Ammonium Nitrate Porous Prills) Local',
 N'KG',
 N'--ไม่ระบุ',
 N'INV25-1609',
 '2025-06-20',
 15000, 15.78, 15.94, 236700, 239100,
 10, N'0-90 Days', '2025-09-29T16:01:10.593');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-07LC',
 N'ANPP SB (Ammonium Nitrate Porous Prills) Local',
 N'KG',
 N'--ไม่ระบุ',
 N'INV25-1365',
 '2025-05-30',
 5100, 16.4, 15.94, 83640, 81294,
 31, N'0-90 Days', '2025-09-29T16:01:10.593');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-06',
 N'Aluminium Powder',
 N'KG',
 N'วัตถุดิบ-วัตถุดิบ',
 N'PV-JH202401',
 '2024-10-11',
 12000, 130.416, 131.75, 1564992, 1581000,
 262, N'181-365 Days', '2025-09-29T16:01:10.583');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-05LC',
 N'Glass Micro balloon (GMB)  Local',
 N'KG',
 N'--ไม่ระบุ',
 N'SP68/010',
 '2025-05-03',
 8158.5, 194, 194, 1582749, 1582749,
 58, N'0-90 Days', '2025-09-29T16:01:10.570');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-04LC',
 N'Solar Emulsifier Blend (SEB)  Local',
 N'KG',
 N'วัตถุดิบ-วัตถุดิบ',
 N'SP68/011',
 '2025-06-02',
 20000, 120.15, 123.13, 2403000, 2462600,
 28, N'0-90 Days', '2025-09-29T16:01:10.560');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-04LC',
 N'Solar Emulsifier Blend (SEB)  Local',
 N'KG',
 N'วัตถุดิบ-วัตถุดิบ',
 N'SP68/008',
 '2025-04-01',
 19500, 126.18, 123.13, 2460510, 2401035,
 90, N'0-90 Days', '2025-09-29T16:01:10.560');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-03LC',
 N'Zinc Nitrate Local',
 N'KG',
 N'--ไม่ระบุ',
 N'IV6804160',
 '2025-04-29',
 308.79, 122, 122, 37672.38, 37672.38,
 62, N'0-90 Days', '2025-09-29T16:01:10.553');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-02 LC',
 N'Sodium Nitrate Local',
 N'KG',
 N'--ไม่ระบุ',
 N'TINV-250629',
 '2025-06-11',
 24000, 20, 20, 480000, 480000,
 19, N'0-90 Days', '2025-09-29T16:01:10.540');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-02 LC',
 N'Sodium Nitrate Local',
 N'KG',
 N'--ไม่ระบุ',
 N'TINV-250417',
 '2025-04-30',
 4100, 20, 20, 82000, 82000,
 61, N'0-90 Days', '2025-09-29T16:01:10.540');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-01',
 N'ANCP JB (Ammonium Nitrate Crystalline)',
 N'KG',
 N'--ไม่ระบุ',
 N'SA68/1027',
 '2025-06-25',
 30000, 17.5, 17.5, 525000, 525000,
 5, N'0-90 Days', '2025-09-29T16:01:10.527');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PRM(C)-01',
 N'ANCP JB (Ammonium Nitrate Crystalline)',
 N'KG',
 N'--ไม่ระบุ',
 N'SA68/0975',
 '2025-06-18',
 5000, 17.5, 17.5, 87500, 87500,
 12, N'0-90 Days', '2025-09-29T16:01:10.527');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00003-PVX สาขา 3',
 N'PE-Waste',
 N'Packaged Emulsion Waste',
 N'KG',
 N'--ไม่ระบุ',
 N'FR0001/0000002',
 '2024-09-25',
 32.18, 41.3754, 41.38, 1331.460372, 1331.6084,
 278, N'181-365 Days', '2025-09-29T16:01:10.517');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00002-สาขาสระบุรี',
 N'XGS62-003',
 N'Elemented Cap 500ms',
 N'PCS',
 N'RSI-เชื้อปะทุดิบ',
 N'RMFIM-PO-62-001',
 '2019-04-01',
 88, 61.248, 76.95, 5389.824, 6771.6,
 2282, N'Over 365 Days', '2025-09-29T16:01:10.507');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00002-สาขาสระบุรี',
 N'XGS62-002',
 N'Elemented Cap 225ms',
 N'PCS',
 N'RSI-เชื้อปะทุดิบ',
 N'RMFIM-PO-62-001',
 '2019-04-01',
 78, 61.248, 76.95, 4777.344, 6002.1,
 2282, N'Over 365 Days', '2025-09-29T16:01:10.500');

INSERT INTO [dbo].[VVPVSG_INVENTORY_001_VIEW_001]
(dataDate, corp, branch, prodCode, prodName, unitName, prodGrp, docNumber, docDate,
 qtyFromThisDoc, buyPrice, averageCost, totalFromBuyPrice, totalFromAverageCost,
 daysAge, ageBucket, createDate)
VALUES
('2025-06-30',
 N'PVX_1-P.V.EXPLOSIVE (THAILAND) CO., LTD.',
 N'00002-สาขาสระบุรี',
 N'XGS62-001',
 N'Elemented Cap 0ms',
 N'PCS',
 N'RSI-เชื้อปะทุดิบ',
 N'RMFIM-PO-62-001',
 '2019-04-01',
 88, 61.248, 76.95, 5389.824, 6771.6,
 2282, N'Over 365 Days', '2025-09-29T16:01:10.490');

GO
